# app/api/endpoints/__init__.py
# Arquivo de inicialização vazio para o pacote endpoints