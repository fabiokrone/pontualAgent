# app/core/config.py
import os
from typing import Optional, Dict, Any, List
from pydantic import BaseSettings, validator
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

class Settings(BaseSettings):
    # Configurações da aplicação
    PROJECT_NAME: str = os.getenv("PROJECT_NAME", "Sistema Automatizado de Gestão de Ponto")
    API_PREFIX: str = os.getenv("API_PREFIX", "/api")
    CORS_ORIGINS: str = os.getenv("CORS_ORIGINS", "http://localhost,http://localhost:8000")
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"
    
    # Configurações do banco de dados
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "postgres")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "gestao_ponto")
    POSTGRES_SERVER: str = os.getenv("POSTGRES_SERVER", "localhost")
    POSTGRES_PORT: str = os.getenv("POSTGRES_PORT", "5432")
    
    # Configurações avançadas do banco de dados
    DB_POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "5"))
    DB_MAX_OVERFLOW: int = int(os.getenv("DB_MAX_OVERFLOW", "10"))
    DB_POOL_TIMEOUT: int = int(os.getenv("DB_POOL_TIMEOUT", "30"))
    DB_POOL_RECYCLE: int = int(os.getenv("DB_POOL_RECYCLE", "1800"))
    DB_ECHO_LOG: bool = os.getenv("DB_ECHO_LOG", "False").lower() == "true"
    
    # Configurações de autenticação
    SECRET_KEY: str = os.getenv("SECRET_KEY", "sua_chave_secreta_padrao_deve_ser_alterada_em_producao")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
    
    # Configurações de integração WhatsApp
    WHATSAPP_API_TYPE: str = os.getenv("WHATSAPP_API_TYPE", "official")  # "evolution" ou "official"
    WHATSAPP_API_URL: Optional[str] = os.getenv("WHATSAPP_API_URL")
    WHATSAPP_API_TOKEN: Optional[str] = os.getenv("WHATSAPP_API_TOKEN")
    WHATSAPP_PHONE_NUMBER_ID: Optional[str] = os.getenv("WHATSAPP_PHONE_NUMBER_ID")  # Necessário apenas para API oficial
    
    # Montar URI do banco de dados
    @property
    def DATABASE_URI(self) -> str:
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    # Validar e processar CORS_ORIGINS
    @property
    def CORS_ORIGINS_LIST(self) -> List[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Criar instância de configurações
settings = Settings()
