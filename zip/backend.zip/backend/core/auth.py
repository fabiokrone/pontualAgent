# app/core/auth.py
from datetime import datetime, timedelta
from typing import Optional, List, Union, Any

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.models.usuario import Usuario

# Configuração de segurança
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_PREFIX}/auth/token")

# Modelos Pydantic para autenticação
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    scopes: List[str] = []

class UserInDB(BaseModel):
    id: int
    username: str
    email: str
    nome_completo: str
    ativo: bool
    perfil: str
    secretaria_id: Optional[int] = None
    
    class Config:
        orm_mode = True

# Funções de autenticação
def verificar_senha(senha_plana: str, senha_hash: str) -> bool:
    """Verifica se a senha plana corresponde ao hash armazenado."""
    return pwd_context.verify(senha_plana, senha_hash)

def obter_hash_senha(senha_plana: str) -> str:
    """Gera um hash para a senha plana."""
    return pwd_context.hash(senha_plana)

def autenticar_usuario(db: Session, username: str, senha: str) -> Optional[Usuario]:
    """Autentica um usuário verificando suas credenciais."""
    usuario = db.query(Usuario).filter(Usuario.username == username).first()
    if not usuario:
        return None
    if not verificar_senha(senha, usuario.senha_hash):
        return None
    return usuario

def criar_token_acesso(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Cria um token JWT de acesso."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

async def obter_usuario_atual(
    token: str = Depends(oauth2_scheme), 
    db: Session = Depends(get_db)
) -> UserInDB:
    """Obtém o usuário atual a partir do token JWT."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciais inválidas",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username, scopes=payload.get("scopes", []))
    except JWTError:
        raise credentials_exception
    
    usuario = db.query(Usuario).filter(Usuario.username == token_data.username).first()
    if usuario is None:
        raise credentials_exception
    if not usuario.ativo:
        raise HTTPException(status_code=400, detail="Usuário inativo")
    
    return UserInDB.from_orm(usuario)

# Dependências para verificação de permissões
def verificar_admin(usuario_atual: UserInDB = Depends(obter_usuario_atual)) -> UserInDB:
    """Verifica se o usuário atual tem perfil de administrador."""
    if usuario_atual.perfil != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Permissão insuficiente",
        )
    return usuario_atual

def verificar_gestor(usuario_atual: UserInDB = Depends(obter_usuario_atual)) -> UserInDB:
    """Verifica se o usuário atual tem perfil de gestor ou administrador."""
    if usuario_atual.perfil not in ["admin", "gestor"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Permissão insuficiente",
        )
    return usuario_atual

def verificar_secretaria_acesso(
    secretaria_id: int,
    usuario_atual: UserInDB = Depends(obter_usuario_atual),
) -> bool:
    """Verifica se o usuário tem acesso à secretaria especificada."""
    # Administradores têm acesso a todas as secretarias
    if usuario_atual.perfil == "admin":
        return True
    
    # Gestores só têm acesso à sua própria secretaria
    if usuario_atual.perfil == "gestor" and usuario_atual.secretaria_id == secretaria_id:
        return True
    
    # Outros usuários não têm acesso
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Sem permissão para acessar esta secretaria",
    )

def verificar_permissao_justificativa(
    justificativa_id: int,
    db: Session = Depends(get_db),
    usuario_atual: UserInDB = Depends(obter_usuario_atual),
) -> bool:
    """Verifica se o usuário tem permissão para aprovar/rejeitar uma justificativa."""
    from app.models.justificativa import Justificativa
    from app.models.servidor import Servidor
    
    # Buscar a justificativa
    justificativa = db.query(Justificativa).filter(Justificativa.id == justificativa_id).first()
    if not justificativa:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Justificativa não encontrada",
        )
    
    # Buscar o servidor da justificativa
    servidor = db.query(Servidor).filter(Servidor.id == justificativa.servidor_id).first()
    if not servidor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Servidor não encontrado",
        )
    
    # Verificar permissão
    return verificar_secretaria_acesso(servidor.secretaria_id, usuario_atual)
